<?php
    $username = 'root';
    $password = '';
    $connection = new PDO( 'mysql:host=localhost;dbname=image_upload_ajax', $username, $password );
?>